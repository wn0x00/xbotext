

import winreg




